function responsiveControll() {

}


$(function () {




    
    $("#menu-btn").bind('click', function () {
        $('#sidebar').sidebar('toggle');
    });

    responsiveControll();




    $('.ui.dropdown').dropdown({
        on: 'hover'
    });

    $('.message .close')
            .on('click', function () {
                $(this)
                        .closest('.message')
                        .transition('vertical flip')
                        ;
            });


    $('.ui.accordion')
            .accordion()
            ;

    $('.progress').progress('increment');


    $('.ui.rating').rating();

    $('.menu.tabing .item')
            .tab()
            ;





//#############################################################################
//                               meni control
//#############################################################################

    $("#menu-control").bind('click', function () {
        $('#side-bar').sidebar('toggle');
    });

//#############################################################################
//                               window scrolling 
//#############################################################################

    $(window).bind('scroll', function (e) {
        

    });

//#############################################################################
//                               window resize 
//#############################################################################

    $(window).bind('resize', function (e) {

        responsiveControll();
    });


//#############################################################################
//                               nice scroll
//#############################################################################

    nice = $("body").niceScroll({
        scrollspeed: 60,
        mousescrollstep: 80,
        horizrailenabled: false
    });

});