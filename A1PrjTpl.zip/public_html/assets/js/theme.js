

;

// handle jquery
$(function () {
    
});

// after load page
$(window).load(function () {
    
});